var indexSectionsWithContent =
{
  0: "cgilmopruw",
  1: "im",
  2: "mu",
  3: "cgmorw",
  4: "gimprw",
  5: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "File",
  3: "Funzioni",
  4: "Variabili",
  5: "Pagine"
};

