var menudata={children:[
{text:"Pagina Principale",url:"index.html"},
{text:"Classi",url:"annotated.html",children:[
{text:"Elenco dei tipi composti",url:"annotated.html"},
{text:"Indice dei tipi composti",url:"classes.html"},
{text:"Membri dei composti",url:"functions.html",children:[
{text:"Tutto",url:"functions.html"},
{text:"Variabili",url:"functions_vars.html"}]}]},
{text:"File",url:"files.html",children:[
{text:"Elenco dei file",url:"files.html"},
{text:"Elementi dei file",url:"globals.html",children:[
{text:"Tutto",url:"globals.html",children:[
{text:"c",url:"globals.html#index_c"},
{text:"g",url:"globals.html#index_g"},
{text:"m",url:"globals.html#index_m"},
{text:"o",url:"globals.html#index_o"},
{text:"r",url:"globals.html#index_r"},
{text:"w",url:"globals.html#index_w"}]},
{text:"Funzioni",url:"globals_func.html",children:[
{text:"c",url:"globals_func.html#index_c"},
{text:"g",url:"globals_func.html#index_g"},
{text:"m",url:"globals_func.html#index_m"},
{text:"o",url:"globals_func.html#index_o"},
{text:"r",url:"globals_func.html#index_r"},
{text:"w",url:"globals_func.html#index_w"}]}]}]}]}
