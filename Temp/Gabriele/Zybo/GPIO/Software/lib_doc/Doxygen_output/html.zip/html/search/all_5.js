var searchData=
[
  ['open_5fdevice',['open_device',['../utils_8h.html#a54da903ecd3a9b22d20f988797be33a8',1,'utils.c']]]
];
