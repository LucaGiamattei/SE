var indexSectionsWithContent =
{
  0: "cgmoruw",
  1: "cmu",
  2: "morw",
  3: "gr"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "File",
  2: "Funzioni",
  3: "Pagine"
};

