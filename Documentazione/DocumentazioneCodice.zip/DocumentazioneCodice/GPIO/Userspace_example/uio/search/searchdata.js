var indexSectionsWithContent =
{
  0: "cghimpruw",
  1: "m",
  2: "cmu",
  3: "chmprw",
  4: "gimprw",
  5: "cgr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "File",
  3: "Funzioni",
  4: "Variabili",
  5: "Pagine"
};

