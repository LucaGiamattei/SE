var searchData=
[
  ['setup',['setup',['../main_8c.html#ac3f3ffc3436562255cd4b9cbe9f2886c',1,'main.c']]]
];
