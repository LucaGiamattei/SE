var searchData=
[
  ['gic_5fdisable',['gic_disable',['../utils_8h.html#a707d921db281f7b19689d6b8b2ed9c22',1,'utils.c']]],
  ['gic_5fenable',['gic_enable',['../utils_8h.html#ab64a782db0d8bd8597505d142d368930',1,'utils.c']]],
  ['gic_5fregister_5finterrupt',['gic_register_interrupt',['../utils_8h.html#ab3ac7ab2c6b78dddc12f63da0c15a3e0',1,'utils.c']]],
  ['gic_5fregister_5finterrupt_5fhandler',['gic_register_interrupt_handler',['../utils_8h.html#a71095f45e99c6d0ea56d85de68c5974f',1,'utils.c']]],
  ['gpio_5fswt_5firqhandler',['gpio_swt_IRQHandler',['../main_8c.html#a4795e35bffa426654f8793e292bebd69',1,'main.c']]]
];
