var indexSectionsWithContent =
{
  0: "cdmruw",
  1: "m",
  2: "cmu",
  3: "cmrw",
  4: "d",
  5: "m",
  6: "u"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "File",
  3: "Funzioni",
  4: "Variabili",
  5: "Gruppi",
  6: "Pagine"
};

