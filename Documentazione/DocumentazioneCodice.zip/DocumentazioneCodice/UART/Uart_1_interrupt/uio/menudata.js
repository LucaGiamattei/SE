var menudata={children:[
{text:"Pagina Principale",url:"index.html"},
{text:"Moduli",url:"modules.html"},
{text:"Classi",url:"annotated.html",children:[
{text:"Elenco dei tipi composti",url:"annotated.html"},
{text:"Indice dei tipi composti",url:"classes.html"},
{text:"Membri dei composti",url:"functions.html",children:[
{text:"Tutto",url:"functions.html"},
{text:"Variabili",url:"functions_vars.html"}]}]},
{text:"File",url:"files.html",children:[
{text:"Elenco dei file",url:"files.html"},
{text:"Elementi dei file",url:"globals.html",children:[
{text:"Tutto",url:"globals.html"},
{text:"Funzioni",url:"globals_func.html"}]}]}]}
