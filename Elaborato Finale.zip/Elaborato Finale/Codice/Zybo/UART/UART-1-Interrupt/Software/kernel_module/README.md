File necessari per compilare il modulo kernel per poter utilizzare la perifierica UART descritta dai file presenti in UART/UART-1-Interrupt/Hardware, ottenendo un file .ko
