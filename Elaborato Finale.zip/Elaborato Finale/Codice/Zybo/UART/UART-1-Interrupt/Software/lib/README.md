Librie di supporto per poter utilizzare la perifierica UART descritta dai file presenti in UART/UART-1-Interrupt/Hardware.
Questa deve essere aggiunta ad ogni esempio presente in UART/UART-1-Interruptuserspace_example
