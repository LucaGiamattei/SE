File necessari per flashare il bitstream e utilizzare la periferica custom il cui hardware è descitto dai file contenuti in UART/UART-1-Interrupt/Hardware

E' necessario inserire anche il file devicetree.dtb relativo all'esempio che si desidera utilizzare collocato nelle rispettive cartelle in "Userspace_examples".
