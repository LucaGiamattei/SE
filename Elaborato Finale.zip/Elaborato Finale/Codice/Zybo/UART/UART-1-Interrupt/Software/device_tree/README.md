File necessari per compilare il devicetree generati a partire dall'xsa presente in UART/UART-1-Interrupt/hardware
