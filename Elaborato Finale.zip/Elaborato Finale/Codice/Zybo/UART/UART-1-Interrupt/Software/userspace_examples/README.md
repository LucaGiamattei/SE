Esempi di utilizzo dell'hardware costum descritto dai file presenti in UART/UART-1-Interrupt/Hardware
