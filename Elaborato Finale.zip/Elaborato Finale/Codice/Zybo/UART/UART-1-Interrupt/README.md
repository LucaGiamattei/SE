Versione di UART che espone all'esterno verso la PS un unico segnale d'interrupt
