Librie di supporto per poter utilizzare la perifierica GPIO descritta dai file presenti in GPIO/Hardware.
Questa deve essere aggiunta ad ogni esempio presente in GPIO/userspace_example
