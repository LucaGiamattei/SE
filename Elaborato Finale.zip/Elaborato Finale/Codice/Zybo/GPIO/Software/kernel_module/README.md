File necessari per compilare il modulo kernel per poter utilizzare la perifierica GPIO descritta dai file presenti in GPIO/Hardware, ottenendo un file .ko
