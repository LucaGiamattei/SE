export ARCH=arm
#export CROSS_COMPILE=arm-linux-gnueabihf-
export CROSS_COMPILE=arm-buildroot-linux-uclibcgnueabi-
source /tools/Xilinx/Vitis/2019.2/settings64.sh
#export PATH=$PATH:/tools/Xilinx/Vitis/2019.2/gnu/aarch32/lin/gcc-arm-linux-gnueabi/bin
export PATH=$PATH:/home/jiin995/Linux-on-Zynq/buildroot-2020.02.3/output/host/bin