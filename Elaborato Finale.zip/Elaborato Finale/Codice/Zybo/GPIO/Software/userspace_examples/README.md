Esempi di utilizzo dell'hardware costum descritto dai file presenti in GPIO/Hardware
