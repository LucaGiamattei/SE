includere nel progetto:
- utils.h
- utils.c
- mygpio.h
- mygpio.c
- config.h
- main.c