var menudata={children:[
{text:"Pagina Principale",url:"index.html"},
{text:"Moduli",url:"modules.html"},
{text:"File",url:"files.html",children:[
{text:"Elenco dei file",url:"files.html"},
{text:"Elementi dei file",url:"globals.html",children:[
{text:"Tutto",url:"globals.html"},
{text:"Funzioni",url:"globals_func.html"}]}]}]}
